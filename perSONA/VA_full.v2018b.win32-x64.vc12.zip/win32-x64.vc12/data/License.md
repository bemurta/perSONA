# VA common data

## License

The following files are licensed under Creative Commons BY 4.0

 - WelcomeToVA.wav

The following files are licensed under Creative Commons BY-NC-SA 4.0 by the Institute of Technical Acoustics (ITA), RWTH Aachen University:

 - ITA_Artificial_Head_5x5_44kHz_128.v17.ir.daff
 - Singer.v17.ms.daff
 - Trumpet1.v17.ms.daff
 - HD650_all_inv.wav
 - ambeo_rir_ita_doorway.wav
 
For more information, higher resolutions for academic purposes and commercial use, please contact us.
